-- create
CREATE TABLE EMPLOYEE (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    age TEXT NOT NULL,
    address TEXT NOT NULL
);
-- insert
INSERT INTO EMPLOYEE
VALUES (0001, 'Белогор', '18', 'Москва');
INSERT INTO EMPLOYEE
VALUES (0002, 'Ведогор', '92', 'Каломна');
INSERT INTO EMPLOYEE
VALUES (0003, 'Горисвет', '95', 'Муром');
INSERT INTO EMPLOYEE
VALUES (0004, 'Доброслав', '18', 'Москва');
INSERT INTO EMPLOYEE
VALUES (0005, 'Звенимир', '36', 'Москва');