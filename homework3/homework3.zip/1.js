let temperatureCelsius = prompt("Введите температуру в градусах Цельсия:");

let temperatureFahrenheit = (temperatureCelsius * 9/5) + 32;

alert(`Цельсий: ${temperatureCelsius}, Фаренгейт: ${temperatureFahrenheit}`);