function greeting(name) {
    console.log(`Привет, ${name}!`);
  }
  
  const userName = prompt("Введите ваше имя:");
  greeting(userName)
  
 
 
 
 
 
 





